function J=codec(I, tabla)
% Metodo 2

end